package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import base.BaseClass2;

public class LoginPage2 extends BaseClass2 {
	
	public LoginPage2(ChromeDriver driver) {
		this.driver = driver;
	}

	public LoginPage2 enterUserName() {
		String uName = prop.getProperty("username");
		driver.findElement(By.id("username")).sendKeys(uName);
		return this;
	}
	
	public LoginPage2 enterpassword() {
		String pWord = prop.getProperty("password");
		driver.findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	public WelcomePage clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}

}
