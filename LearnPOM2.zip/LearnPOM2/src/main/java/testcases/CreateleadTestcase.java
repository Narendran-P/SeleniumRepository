package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import base.BaseClass2;
import pages.LoginPage;
import pages.LoginPage2;

public class CreateleadTestcase extends BaseClass2 {
	
	@Test
	public void CreateLead () {
		
		LoginPage2 lp = new LoginPage2(driver);
		lp.enterUserName()
		.enterpassword()
		.clickLoginButton()
		.clickCRMSFA()
		.clickLead()
		.clickCreateLead()
		.companyName()
		.firstName()
		.lastName()
		.clickonSubmit()
		.verifylead();
		
	}

}
