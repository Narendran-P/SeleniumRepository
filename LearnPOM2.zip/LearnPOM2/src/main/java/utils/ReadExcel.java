package utils;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public static String[][] readExcel(String excelName) throws IOException {
		
		XSSFWorkbook wb = new XSSFWorkbook("data/"+excelName+".xlsx");
		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row = sheet.getRow(1);
		XSSFCell cell = row.getCell(0);
		
		System.out.println(cell);
		
		//TO get no. of rows
		int rowcount = sheet.getLastRowNum();
		System.out.println(rowcount);
		//TO get no. of columns
		short columncount = sheet.getRow(0).getLastCellNum();
		System.out.println(columncount);
		
		String[][] data = new String[rowcount][columncount];
		//to read all the data
		for (int i = 1; i <= rowcount; i++) {
			XSSFRow row1 = sheet.getRow(i);
			for (int j = 0; j < columncount; j++) {
				String stringCellValue = row1.getCell(j).getStringCellValue();
				System.out.println(stringCellValue);
				data[i-1][j] = stringCellValue;
			}
			
		}
		wb.close();
		return data;
		
	}

}
