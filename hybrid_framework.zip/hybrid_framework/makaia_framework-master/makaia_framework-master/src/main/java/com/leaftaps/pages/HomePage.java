package com.leaftaps.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	
		
	
	public MyHomePage clickCRMSFALink() {
		click(locateElement(Locators.LINK_TEXT,"CRM/SFA"));
		reportStep("CRM/SFA link is clicked successfully", "pass");
		
		return new MyHomePage();
	}
	
}
