package week6.day1.Assignments;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DeleteLead4 extends BaseClass{

	@Test(dataProvider="DeleteLeadFromExcell1")
	public void deleteLead(String phNum) throws InterruptedException {
	
		System.out.println("==============================================Delete Lead==============================================");
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Find Leads")).click();
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phNum);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		String leadID1 = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		System.out.println("The Lead Id to be deleted is: "+leadID1);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Delete')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Find Leads")).click();
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID1);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		String text = driver.findElement(By.xpath("//div[contains(text(),'No records to display')]")).getText();
		System.out.println(text);
		if (text.equalsIgnoreCase("No records to display")) {
			System.out.println("Lead deleted successfully");
		} else {
			System.out.println("Lead not deleted ");
		}
	}
	
	@DataProvider(name="DeleteLeadFromExcell1")
	public String[][] sendData() throws IOException {
		return ReadExcel2.DeleteLeadfromExcel("Leads");
	}

}
