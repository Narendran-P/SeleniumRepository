package week6.day1.Assignments;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class EditLead4 extends BaseClass {

		@Test(dataProvider="EditLeadfomrexce")
	public void editLead(String phnum, String comName) throws InterruptedException {
			System.out.println("==============================================Edit Lead==============================================");

		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Find Leads")).click();
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phnum);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		driver.findElement(By.linkText("Edit")).click();
		WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys(comName);
		driver.findElement(By.name("submitButton")).click();
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(comName)) {
			System.out.println("Lead editted successfully");
		}
		else {
			System.out.println("Lead not editted. TC falied");
		}
	}
		
		@DataProvider(name="EditLeadfomrexce")
		public String[][] sendData() throws IOException {
			return ReadExcel2.EditLeadfromExcel("Leads");
		}

}
