package week6.day1.Assignments;

import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class ReadExcel2 {
	public static String[][] readExcel(String excelName) throws IOException {
		
		XSSFWorkbook wb = new XSSFWorkbook("data/"+excelName+".xlsx");
		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row = sheet.getRow(1);
		XSSFCell cell = row.getCell(0);
		
		System.out.println(cell);
		
		//TO get no. of rows in CreateLead
		int rowcount = sheet.getLastRowNum();
		System.out.println(rowcount);
		//TO get no. of columns
		short columncount = sheet.getRow(0).getLastCellNum();
		System.out.println(columncount);
		
		String[][] data = new String[rowcount][columncount];
		//to read all the data
		for (int i = 1; i <= rowcount; i++) {
			XSSFRow row1 = sheet.getRow(i);
			for (int j = 0; j < columncount; j++) {
				String stringCellValue = row1.getCell(j).getStringCellValue();
				System.out.println(stringCellValue);
				data[i-1][j] = stringCellValue;
			}
			
		}
		wb.close();
		return data;
	}
	
	public static String[][] EditLeadfromExcel(String excelName) throws IOException {
		// TODO Auto-generated method stub

		//TO get no. of rows in EditLead
		XSSFWorkbook wb1 = new XSSFWorkbook("data/"+excelName+".xlsx");
		XSSFSheet sheet1 = wb1.getSheetAt(1);
		XSSFRow row1 = sheet1.getRow(1);
		
		// to get no. of rows
		int lastRowNum = sheet1.getLastRowNum();
		//to get no. of columns
		int lastCellNum = row1.getLastCellNum();
		
		String[][] data1 = new String [lastRowNum][lastCellNum];
		//to read the data
		for (int i = 1; i <= lastRowNum; i++) {
			XSSFRow row2 = sheet1.getRow(i);
			for (int j = 0; j < lastCellNum; j++) {
				String stringCellValue1 = row2.getCell(j).getStringCellValue();
				data1[i-1][j] = stringCellValue1;
			}
			
			
		}
		
		wb1.close();
		return data1;
	}
	
	public static String[][] DeleteLeadfromExcel(String excelName) throws IOException {
		XSSFWorkbook wb2 = new XSSFWorkbook("data/"+excelName+".xlsx");
		XSSFSheet sheet2 = wb2.getSheetAt(2);
		XSSFRow rowcheck2 = sheet2.getRow(1);
		
		// to get no. of rows
		int lastRowNum1 = sheet2.getLastRowNum();
		//to get no. of columns
		int lastCellNum1 = rowcheck2.getLastCellNum();
		
		String[][] data2 = new String [lastRowNum1][lastCellNum1];
		//to read the data
		for (int i = 1; i <= lastRowNum1; i++) {
			XSSFRow row3 = sheet2.getRow(i);
			for (int j = 0; j < lastCellNum1; j++) {
				String stringCellValue2 = row3.getCell(j).getStringCellValue();
				data2[i-1][j] = stringCellValue2;
			}	
		}
		
		wb2.close();
		return data2;

	}
	
	public static String[][] MergeLeadfromExcel(String excelName) throws IOException {
		XSSFWorkbook wb3 = new XSSFWorkbook("data/"+excelName+".xlsx");
		XSSFSheet sheet3 = wb3.getSheetAt(3);
		XSSFRow rowcheck3 = sheet3.getRow(1);
		
		// to get no. of rows
		int lastRowNum2 = sheet3.getLastRowNum();
		//to get no. of columns
		int lastCellNum2 = rowcheck3.getLastCellNum();
		
		String[][] data3 = new String [lastRowNum2][lastCellNum2];
		//to read the data
		for (int i = 1; i <= lastRowNum2; i++) {
			XSSFRow row4 = sheet3.getRow(i);
			for (int j = 0; j < lastCellNum2; j++) {
				String stringCellValue3 = row4.getCell(j).getStringCellValue();
				data3[i-1][j] = stringCellValue3;
			}	
		}
		
		wb3.close();
		return data3;

	}

}
