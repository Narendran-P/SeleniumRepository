package week6.day1.Assignments;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class MergeLead4 extends BaseClass {
	
	@Test(dataProvider="MergeLeadfromexcell")
	public void mergeLead(String firstName1, String firstName2 ) throws InterruptedException {
		System.out.println("==============================================Merge Lead==============================================");

		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Merge Leads")).click();
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName1);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(3000);
		String leadID2 = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		System.out.println("Lead to be Merged: "+leadID2);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		driver.switchTo().window(allhandles.get(0));
		
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> allWindows2 = driver.getWindowHandles();
		List<String> allhandles2 = new ArrayList<String>(allWindows2);
		driver.switchTo().window(allhandles2.get(1));
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName2);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(3000);
		String leadID3 = driver.findElement(By.xpath("//a[@class='linktext']")).getText();
		System.out.println("Lead to be Merged with: "+leadID3);
		driver.findElement(By.xpath("//a[@class='linktext']")).click();
		driver.switchTo().window(allhandles2.get(0));
		driver.findElement(By.xpath("//a[@class='buttonDangerous']")).click();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.findElement(By.linkText("Find Leads")).click();
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(leadID2);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		String text = driver.findElement(By.className("x-paging-info")).getText();
		System.out.println(text);
		if (text.equalsIgnoreCase("No records to display")) {
			System.out.println("Merge Lead Successful");
		} else {
			System.out.println("Text not matched. Merge Lead is unsuccessful");
		}
	}
	
	@DataProvider(name="MergeLeadfromexcell")
	public String[][] sendData() throws IOException {
		return ReadExcel2.MergeLeadfromExcel("Leads");
	}

}
