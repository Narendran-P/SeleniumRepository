package week6.day1.Assignments;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateLead3 extends BaseClass{
	
	@Test(dataProvider = "fetchdata")
			public void main(String cname, String firstname, String lastname, String phnum) {
			driver.findElement(By.linkText("Leads")).click();
			driver.findElement(By.linkText("Create Lead")).click();
			driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
			driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
			driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
			driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phnum);
		driver.findElement(By.name("submitButton")).click();
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cname)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
		
	}
	
	@DataProvider(name="fetchdata")
	public String[][] sendData() throws IOException {
	return ReadExcel.readExcel("CreatLead2");
	}

}
