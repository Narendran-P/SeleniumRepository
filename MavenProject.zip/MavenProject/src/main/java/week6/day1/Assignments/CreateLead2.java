package week6.day1.Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateLead2 extends BaseClass{
	
	@Test(dataProvider = "fetchdata")
			public void main(String cname, String firstname, String lastname, String phnum) {
			driver.findElement(By.linkText("Leads")).click();
			driver.findElement(By.linkText("Create Lead")).click();
			driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
			driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
			driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
			driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phnum);
		driver.findElement(By.name("submitButton")).click();
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains("Testleaf")) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
		
	}
	
	@DataProvider(name="fetchdata")
	public String[][] sendData() {
		String[][] data = new String[2][4];
		data[0][0] = "Testleaf";
		data[0][1] = "Narendran";
		data[0][2] = "P";
		data[0][3] = "99"; 
		
		data[1][0] = "Testleaf";
		data[1][1] = "Dilip";
		data[1][2] = "Kumar";
		data[1][3] = "90";
		
		return data;
	}

}
