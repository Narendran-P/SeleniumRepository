package week3.Assignments.Assignement3;

public abstract class MultipleLanguage {
	
	public void python() {
 
		System.out.println("This is Python");
	}
	
	public void ruby() {
	
		System.out.println("This is Ruby");

	}

}
