package week3.Assignments.Assignement3;

public interface TestTool {
	
	public void Selenium();

}
