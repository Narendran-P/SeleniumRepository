package week3.Assignments.Assignement3;

public interface Language {
	
	public void Java();

}
