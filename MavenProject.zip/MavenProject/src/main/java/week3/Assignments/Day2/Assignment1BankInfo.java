package week3.Assignments.Day2;

public class Assignment1BankInfo {
	
	public void savings(String sb) {
		System.out.println("This is Saving Account"+sb);
	}
	
	public void fixed(float fd) {
		System.out.println("This is maximum amount for Fixed Deposit: "+fd);
	}
	
	public void deposit(String dp) {
		System.out.println("Require - Aadhar Card: "+dp);
	}

		
	}

