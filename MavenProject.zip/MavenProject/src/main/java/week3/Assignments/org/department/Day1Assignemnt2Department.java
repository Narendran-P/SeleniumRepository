package week3.Assignments.org.department;

import week3.Assignments.org.college.Day1Assignemnt2College;

public class Day1Assignemnt2Department extends Day1Assignemnt2College {
	
	public void deptName(String dept) {

		System.out.println("Thge department name is: "+dept);
	}

}
