package week3.Assignments.org.system;

public class Day1Assignment1Computer {
	public void computerMethod() {

		System.out.println("This is Computer Method");

	}

}
