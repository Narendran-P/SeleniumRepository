package week3.Assignments.org.college;

public class Day1Assignemnt2College {
	
	public void collegeName(String name) {
		
		System.out.println("The College Name is: "+name);
	}
	
	public void collegeCode(int code) {
				System.out.println("The College Code is: "+code);
	}
	
	public void collegeRank(int rank) {
		System.out.println("The College Rank is: "+rank);
	}

}
