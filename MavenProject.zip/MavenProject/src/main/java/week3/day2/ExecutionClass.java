package week3.day2;

public class ExecutionClass {
	
	public static void main(String[] args)  {
		BrowserImplementation br = new BrowserImplementation();
		br.startApp();
		br.startApp("Edge");
	}

}
