package week3.day2;

public interface Browser {
	
	//here we are having two methods with same name
	//each have different implementation
	
	//to start an app
	public void startApp();
	
	//to pass a value during implementation
	public void startApp(String browser);

}
