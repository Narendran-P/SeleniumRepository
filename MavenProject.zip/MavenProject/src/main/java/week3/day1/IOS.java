package week3.day1;

public class IOS {
	
	public void startApp() {
		System.out.println("Start App");
	}
	
	public void increaseVolume() {
		System.out.println("increase Volume");
	}
	
	public void shutdown() {
		System.out.println("shutdown");
	}


}
