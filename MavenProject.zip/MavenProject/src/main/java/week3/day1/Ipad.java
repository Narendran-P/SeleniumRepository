package week3.day1;

public class Ipad extends IOS {

	public void watchMovie() {
		System.out.println("Watch Movie");
	}
}
