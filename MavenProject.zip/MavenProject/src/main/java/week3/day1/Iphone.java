package week3.day1;

public class Iphone extends IOS{

	public void makeCalls() {
		System.out.println("Make Calls");
	}
	
	public void sendSMS() {
		System.out.println("send SMS");
	}
}
