package week3.day1;

public interface Android {
	
	public void openApp();
	
	public void watchVideo();
	

}
