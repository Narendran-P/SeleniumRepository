package week3.day1;

public class OnePlus implements Android {

	@Override
	public void watchVideo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void openApp() {
		// TODO Auto-generated method stub
		
	}


}
