package week3.day1;

public class Samsung extends AndroidTV {

	@Override
	public void watchVideo() {
		// TODO Auto-generated method stub
		
	}

	
}
