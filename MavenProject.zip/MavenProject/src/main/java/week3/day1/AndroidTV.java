package week3.day1;

public abstract class AndroidTV implements Android {

	@Override
	public void openApp() {
		// TODO Auto-generated method stub
		
	}

}
