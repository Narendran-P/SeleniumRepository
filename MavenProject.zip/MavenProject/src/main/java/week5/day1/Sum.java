package week5.day1;

public class Sum {
	
	
	
	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		int c = a + b;
		System.out.println(c);
	}

}

////get all the windowHandles IDs
//Set<String> windowids1=driver.getWindowHandles();
//System.out.println("The window ids are " +windowids1 );
//
////Parent window
//driver.switchTo().window(handles1.get(1));
//
////put all the ids in  List array
//List<String> handles1=new ArrayList<>(windowids1);

