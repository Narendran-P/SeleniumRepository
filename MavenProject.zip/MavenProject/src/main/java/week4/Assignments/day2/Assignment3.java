package week4.Assignments.day2;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment3 {
	
	public static void main(String[] args) throws IOException {
		
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get(" https://www.amazon.in/");
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("oneplus 9 pro ");
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		String priceof1stPdt = driver.findElement(By.xpath("(//span[@class='a-price-whole'])[1]")).getText();
		System.out.println("Price of 1st produce in Result: "+priceof1stPdt);
			
		String custRatings = driver.findElement(By.xpath("(//span[@class='a-size-base s-underline-text'])[1]")).getText();
		System.out.println("No. Of Customer Ratings on 1st product: "+custRatings);
		
		driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
		
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> handles = new ArrayList<>(windowHandles);
		driver.switchTo().window(handles.get(1));
		
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File DestFile = new File("./Snap/Screenshot1winhan.png");
		FileUtils.copyFile(screenshotAs, DestFile);
		
		driver.findElement(By.id("add-to-cart-button")).click();
		
		String addCartPrice = driver.findElement(By.xpath("//span[@class='a-price-whole']")).getText();
		System.out.println("The Price on Add Cart page is: "+addCartPrice);
		
		if (priceof1stPdt.equals(addCartPrice)) {
			System.out.println("The Cart Subtotal is correct and it is: "+addCartPrice);
		}
		else {
			System.out.println("The cart subtotal and Product price is different. Test case Failed");
		}
		
		driver.quit();

	}

}
