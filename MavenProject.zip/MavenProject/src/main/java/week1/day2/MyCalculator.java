package week1.day2;


public class MyCalculator {

	public static void main(String[] args) {
		
	Calculator Cal = new Calculator();
	System.out.println(Cal.mul(2.2f, 2));
	System.out.println("Subtraction of two numbers:"+Cal.sub());
	Cal.vvv();
	}
	
}
