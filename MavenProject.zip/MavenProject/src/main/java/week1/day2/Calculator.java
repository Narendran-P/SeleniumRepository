package week1.day2;

public class Calculator {
	
	private int addTwoNumbers(int num1, int num2) {
	return num1+num2;
	}
	
	public float mul(float num1, int num2) {
	return num1*num2;
}

	public int sub() {
		
	int num1 = 2;
	int num2 = 1;
	int c = num1-num2;
		return c;
	}
	
	public void vvv() {
		System.out.println("subtraction of two number is 0");
	}
	
	public static void main(String[] args) {
		
	}
}