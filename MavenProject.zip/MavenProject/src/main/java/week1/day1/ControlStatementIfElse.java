package week1.day1;

public class ControlStatementIfElse {
public static void main(String[] args) {
	
	int a = 50;
	
	if (a > 0) {
		System.out.println("The number is Positive");
	}
	else if (a == 0) {
		System.out.println("The number is Neutral");
	}
	if (a < 0) {
		System.out.println("The number is negative");
	}
}
}
