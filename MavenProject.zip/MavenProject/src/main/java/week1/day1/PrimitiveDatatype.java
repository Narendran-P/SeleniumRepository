package week1.day1;

public class PrimitiveDatatype {
public static void main(String[] args) {
	int fieldInt = 12345;
	boolean fieldBoolean = true;
	String fieldString = "Selenium";
	long creditNum = 123123123123l;
	float fieldFloat = 1.11f;
	double fieldDouble = 65431.12343;
	char fieldChar = 'a';
	String name = "Narendran";
	int age = 29;
	
	System.out.println("Interger value : "+fieldInt);
	System.out.println("Boolean value : "+fieldBoolean);
	System.out.println("String value : "+fieldString);
	System.out.println("Long int value : "+creditNum);
	System.out.println("Float value : "+fieldFloat);
	System.out.println("Double value : "+fieldDouble);
	System.out.println("Char value : "+fieldChar);
	System.out.println("My Name is "+name+". "+"My Age is "+age);



}
}
