package week1.Assignments0819;

public class NegativeToPositive {
	
	public static void main(String[] args) {
		
		int a = - 10;
		int b;
		
		if(a<0) {
			b = ( a * -1);
			System.out.println("The number "+a+" is converted to "+b);
		}
	}

}
