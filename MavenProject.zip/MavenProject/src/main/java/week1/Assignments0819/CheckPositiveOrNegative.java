package week1.Assignments0819;

public class CheckPositiveOrNegative {

	public static void main(String[] args) {
		int a = 0;
		
		if(a<0) {
			System.out.println("The Number is negative");
	}
		else if (a>0) {
			System.out.println("The Number is Positive");
		}
		else {
			System.out.println("The Number is neither Positive nor Negative");
		}
}
}
