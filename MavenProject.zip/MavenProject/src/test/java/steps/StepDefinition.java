package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class StepDefinition {
	
	public ChromeDriver driver;
	
	@Given("Launch the browser")
	public void launchbrowser() {
		 driver = new ChromeDriver();
	}
	
	@And("Load the URL")
	public void loadtheURl() {
		driver.get("http://leaftaps.com/opentaps/control/main");
	}
	
	@And("Enter the username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	@And("Enter the password as {string}")
	public void enterpassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	@When("click on Login button")
	public void clickonLoginbutton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	@Then("Homepage should be displayed")
	public void verifyHomepage() {
		String element = driver.findElement(By.xpath("//h2[contains(text(),'Welcome')]")).getText();
		
		if (element.contains("Welcome")) {
			System.out.println("The Home page opened successfully. Text case passed");
		}
		else {
			System.out.println("The Home page not displayed. Test case failed");
		}

	}
	
	@But("Error Message should be displayed")
	public void Errormessage() {
		
		String element1 = driver.findElement(By.xpath("//p[contains(text(),'Errors')]")).getText();
		
		if (element1.contains("Error")) {
			System.out.println("Error displayed. User Not logged in. Text case passed");
		}
		else {
			System.out.println("The Home page displayed. negative Test case - failed");
		}


	}
	
	@When("click on crmsfa link")
	public void click_on_crmsfa_link() {
		  driver.findElement(By.partialLinkText("CRM/SFA")).click();
	}
	
	@When("click on Leads link")
	public void click_on_leads_link() {
		driver.findElement(By.linkText("Leads")).click();
	}
	
	@When("click on CreateLead link")
	public void click_on_create_lead_link() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	@Given("Enter Company Name as (.*)$")
	public void enter_company_name_as_test_leaf(String cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
	}
	
	@Given("Enter firstname as (.*)$")
	public void enter_firstname_as_narendran(String firstname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
	}
	@Given("Enter lastname as (.*)$")
	public void enter_lastname_as_p(String lastname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
	}
	
	@When("click on Submit button")
	public void click_on_submit_button() {
		driver.findElement(By.name("submitButton")).click();
	}
	
	@Then("ViewLeads page should be displayed as (.*)$")
	public void view_leads_page_should_be_displayed_as_testleaf(String cname) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cname)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
	}
	
	@Given("Close the browser")
	public void closebrowser() {
		driver.close();
	}
	
	

}
